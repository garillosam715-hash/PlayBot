#pragma once
#include <Geode/Geode.hpp>
#include <deque>

using namespace geode::prelude;

namespace playbot {

// A CCDrawNode-based overlay that lives inside PlayLayer and renders:
//  - a fading trajectory trail behind the player (for showcase videos)
//  - live hitbox outlines for the player + nearby hazards (for
//    verification / showcase recording, so viewers can see exact clips)
class ShowcaseRenderLayer : public CCLayer {
public:
    static ShowcaseRenderLayer* create();
    bool init() override;
    void update(float dt) override;

    void setTrajectoryEnabled(bool enabled) { m_trajectoryEnabled = enabled; }
    void setHitboxesEnabled(bool enabled)   { m_hitboxEnabled = enabled; }

private:
    CCDrawNode* m_drawNode = nullptr;
    std::deque<CCPoint> m_trailPoints;
    bool m_trajectoryEnabled = false;
    bool m_hitboxEnabled = false;

    static constexpr size_t kMaxTrailPoints = 120;

    void drawTrajectory();
    void drawHitboxes();
};

} // namespace playbot
