#include "Render.hpp"
#include <Geode/modify/PlayLayer.hpp>

using namespace geode::prelude;
using namespace playbot;

ShowcaseRenderLayer* ShowcaseRenderLayer::create() {
    auto ret = new ShowcaseRenderLayer();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    CC_SAFE_DELETE(ret);
    return nullptr;
}

bool ShowcaseRenderLayer::init() {
    if (!CCLayer::init()) return false;

    m_drawNode = CCDrawNode::create();
    this->addChild(m_drawNode, 100);

    this->scheduleUpdate();
    return true;
}

void ShowcaseRenderLayer::update(float dt) {
    m_drawNode->clear();

    auto pl = GameManager::get()->getPlayLayer();
    if (!pl || !pl->m_player1) return;

    if (m_trajectoryEnabled) {
        m_trailPoints.push_back(pl->m_player1->getPosition());
        if (m_trailPoints.size() > kMaxTrailPoints) {
            m_trailPoints.pop_front();
        }
        drawTrajectory();
    } else if (!m_trailPoints.empty()) {
        m_trailPoints.clear();
    }

    if (m_hitboxEnabled) {
        drawHitboxes();
    }
}

void ShowcaseRenderLayer::drawTrajectory() {
    if (m_trailPoints.size() < 2) return;

    ccColor4B color = Mod::get()->getSettingValue<ccColor4B>("trail-color");

    for (size_t i = 1; i < m_trailPoints.size(); ++i) {
        // Fade older segments so the trail reads as motion, not a static line.
        float alphaFactor = static_cast<float>(i) / static_cast<float>(m_trailPoints.size());
        ccColor4F segColor = {
            color.r / 255.f,
            color.g / 255.f,
            color.b / 255.f,
            (color.a / 255.f) * alphaFactor
        };
        m_drawNode->drawSegment(m_trailPoints[i - 1], m_trailPoints[i], 2.f, segColor);
    }
}

void ShowcaseRenderLayer::drawHitboxes() {
    auto pl = GameManager::get()->getPlayLayer();
    if (!pl || !pl->m_player1) return;

    ccColor4B color = Mod::get()->getSettingValue<ccColor4B>("hitbox-color");
    ccColor4F c = { color.r / 255.f, color.g / 255.f, color.b / 255.f, color.a / 255.f };

    auto drawBox = [&](CCNode* node) {
        if (!node) return;
        auto rect = node->boundingBox();
        CCPoint pts[4] = {
            {rect.getMinX(), rect.getMinY()},
            {rect.getMaxX(), rect.getMinY()},
            {rect.getMaxX(), rect.getMaxY()},
            {rect.getMinX(), rect.getMaxY()},
        };
        for (int i = 0; i < 4; ++i) {
            m_drawNode->drawSegment(pts[i], pts[(i + 1) % 4], 1.5f, c);
        }
    };

    drawBox(pl->m_player1);
    if (pl->m_player2) drawBox(pl->m_player2);

    // Draw hitboxes for objects currently near the player, so nearby
    // hazards are visible on-screen for showcase/verification clips
    // without flooding the draw call with the whole level.
    if (pl->m_objects) {
        auto playerPos = pl->m_player1->getPosition();
        CCARRAY_FOREACH_B_TYPE(pl->m_objects, obj, GameObject) {
            if (!obj || !obj->m_isDamageAble) continue;
            float dist = ccpDistance(obj->getPosition(), playerPos);
            if (dist < 400.f) {
                drawBox(obj);
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Hook: attach the render layer to every PlayLayer instance.
// ---------------------------------------------------------------------------
class $modify(PBRenderPlayLayer, PlayLayer) {
    struct Fields {
        ShowcaseRenderLayer* m_showcaseLayer = nullptr;
    };

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;

        auto layer = ShowcaseRenderLayer::create();
        layer->setTrajectoryEnabled(Mod::get()->getSettingValue<bool>("render-trajectory"));
        layer->setHitboxesEnabled(Mod::get()->getSettingValue<bool>("render-hitboxes"));
        this->addChild(layer, 1000);
        m_fields->m_showcaseLayer = layer;

        return true;
    }
};
