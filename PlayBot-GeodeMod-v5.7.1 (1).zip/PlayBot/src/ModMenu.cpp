#include <Geode/Geode.hpp>
#include <Geode/modify/PauseLayer.hpp>
#include "Hacks.hpp"
#include "Render.hpp"

using namespace geode::prelude;
using namespace playbot;

// A compact popup that lists every PlayBot toggle with a live on/off
// button, so players don't have to dig through the mod settings menu
// mid-level. Purely a UX layer on top of the same settings backend.
class PlayBotMenuPopup : public geode::Popup<> {
protected:
    bool setup() override {
        this->setTitle("PlayBot");

        auto winSize = CCDirector::sharedDirector()->getWinSize();
        float startY = winSize.height / 2 + 70.f;
        float rowHeight = 34.f;

        struct Row { const char* key; const char* label; };
        std::vector<Row> rows = {
            {"noclip",              "NoClip"},
            {"speedhack",           "Speedhack"},
            {"click-between-frames","Click Between Frames"},
            {"auto-save",           "Auto Save Checkpoints"},
            {"render-trajectory",   "Showcase Trajectory Render"},
            {"render-hitboxes",     "Showcase Hitbox Render"},
        };

        for (size_t i = 0; i < rows.size(); ++i) {
            auto label = CCLabelBMFont::create(rows[i].label, "bigFont.fnt");
            label->setScale(0.4f);
            label->setAnchorPoint({0.f, 0.5f});
            label->setPosition({-140.f, startY - i * rowHeight - m_size.height / 2 + 100.f});
            m_mainLayer->addChild(label);

            bool current = Mod::get()->getSettingValue<bool>(rows[i].key);
            auto onSprite  = ButtonSprite::create("ON",  40, true, "bigFont.fnt", "GJ_button_01.png", 24.f, 0.7f);
            auto offSprite = ButtonSprite::create("OFF", 40, true, "bigFont.fnt", "GJ_button_02.png", 24.f, 0.7f);

            auto toggle = CCMenuItemToggler::create(
                onSprite, offSprite, this, menu_selector(PlayBotMenuPopup::onToggle)
            );
            toggle->toggle(current);
            toggle->setTag(static_cast<int>(i));

            auto menu = CCMenu::create();
            menu->addChild(toggle);
            menu->setPosition({120.f, startY - i * rowHeight - m_size.height / 2 + 100.f});
            m_mainLayer->addChild(menu);

            m_keys.push_back(rows[i].key);
        }

        return true;
    }

    void onToggle(CCObject* sender) {
        auto item = static_cast<CCMenuItemToggler*>(sender);
        int tag = item->getTag();
        bool newState = !item->isToggled(); // isToggled() reflects pre-click state

        Mod::get()->setSettingValue<bool>(m_keys[tag], newState);
        HackState::get().refreshFromSettings();
    }

    std::vector<std::string> m_keys;

public:
    static PlayBotMenuPopup* create() {
        auto ret = new PlayBotMenuPopup();
        if (ret && ret->initAnchored(320.f, 280.f)) {
            ret->autorelease();
            return ret;
        }
        CC_SAFE_DELETE(ret);
        return nullptr;
    }
};

// Adds a small "PB" button to the pause menu that opens the popup above.
class $modify(PBPauseLayer, PauseLayer) {
    void customSetup() {
        PauseLayer::customSetup();

        if (!Mod::get()->getSettingValue<bool>("menu-keybind")) return;

        auto menu = this->getChildByID("pause-menu");
        if (!menu) menu = this->getChildByType<CCMenu>(0);
        if (!menu) return;

        auto sprite = ButtonSprite::create("PB", 40, true, "bigFont.fnt", "GJ_button_04.png", 30.f, 0.9f);
        auto btn = CCMenuItemSpriteExtra::create(
            sprite, this, menu_selector(PBPauseLayer::onPlayBotMenu)
        );
        btn->setID("playbot-menu-button"_spr);
        btn->setPosition({-150.f, 100.f});
        menu->addChild(btn);
    }

    void onPlayBotMenu(CCObject*) {
        PlayBotMenuPopup::create()->show();
    }
};
