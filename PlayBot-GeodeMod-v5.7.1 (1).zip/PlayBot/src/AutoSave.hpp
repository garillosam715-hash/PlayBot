#pragma once
#include <Geode/Geode.hpp>

using namespace geode::prelude;

namespace playbot {

// Periodically drops a practice checkpoint while the player is in
// practice mode, so a crash, alt-F4, or accidental exit never costs
// more than `auto-save-interval` seconds of practice progress.
class AutoSaveManager {
public:
    static AutoSaveManager& get() {
        static AutoSaveManager instance;
        return instance;
    }

    void tick(float dt, PlayLayer* pl);
    void reset();

private:
    float m_timer = 0.f;
};

} // namespace playbot
