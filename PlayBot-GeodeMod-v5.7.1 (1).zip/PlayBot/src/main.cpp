#include <Geode/Geode.hpp>
#include "Hacks.hpp"

using namespace geode::prelude;
using namespace playbot;

$execute {
    log::info("PlayBot loaded — full modded practice/showcase toolkit online.");

    // Keep HackState in sync whenever the player changes a setting from
    // the mod settings page (as opposed to the in-game PlayBot popup,
    // which updates it directly).
    listenForSettingChanges<bool>("noclip", [](bool) {
        HackState::get().refreshFromSettings();
    });
    listenForSettingChanges<bool>("speedhack", [](bool) {
        HackState::get().refreshFromSettings();
    });
    listenForSettingChanges<float>("speedhack-multiplier", [](float) {
        HackState::get().refreshFromSettings();
    });
    listenForSettingChanges<bool>("click-between-frames", [](bool) {
        HackState::get().refreshFromSettings();
    });
}
