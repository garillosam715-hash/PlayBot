#include "Hacks.hpp"
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/modify/CCScheduler.hpp>

using namespace geode::prelude;
using namespace playbot;

void HackState::refreshFromSettings() {
    noClipEnabled      = Mod::get()->getSettingValue<bool>("noclip");
    speedhackEnabled   = Mod::get()->getSettingValue<bool>("speedhack");
    clickBetweenFrames = Mod::get()->getSettingValue<bool>("click-between-frames");
    speedMultiplier     = Mod::get()->getSettingValue<float>("speedhack-multiplier");
}

// ---------------------------------------------------------------------------
// NoClip
// ---------------------------------------------------------------------------
// Practice-mode-only safety net: intercepts the death callback and, when
// enabled, cancels the death so the player phases through hazards. This is
// intended for dissecting a level's geometry / testing routes, not for
// falsifying level completions or leaderboard submissions.
class $modify(PBPlayerObject, PlayerObject) {
    void playerDestroyed(bool p0) {
        auto& state = HackState::get();
        auto pl = GameManager::get()->getPlayLayer();

        if (state.noClipEnabled && pl && pl->m_isPracticeMode) {
            // Swallow the death entirely while in practice mode.
            return;
        }

        PlayerObject::playerDestroyed(p0);
    }
};

// ---------------------------------------------------------------------------
// Speedhack
// ---------------------------------------------------------------------------
// Scales CCScheduler's global time factor, which changes effective game
// speed without touching audio pitch handling that PlayLayer does itself.
class $modify(PBScheduler, CCScheduler) {
    void update(float dt) {
        auto& state = HackState::get();
        if (state.speedhackEnabled) {
            CCScheduler::update(dt * state.speedMultiplier);
        } else {
            CCScheduler::update(dt);
        }
    }
};

// ---------------------------------------------------------------------------
// Click Between Frames (sub-frame input precision)
// ---------------------------------------------------------------------------
// Standard "CBF" style implementation: instead of only registering a
// click/release on the next rendered frame, we timestamp the raw touch/press
// event and, on the following update, apply it at the correct fractional
// point within that frame's physics step for frame-perfect precision.
//
// NOTE: As of GD 2.208, the base game ships an official native equivalent
// ("Click on Steps") in its own settings menu. This mod-side implementation
// is kept independent and toggleable so behavior stays consistent for
// players/servers that specifically expect classic third-party CBF timing,
// rather than silently deferring to whatever the native option does.
class $modify(PBPlayLayer, PlayLayer) {
    struct Fields {
        double m_pendingPressTime = -1.0;
        bool m_pendingPressDown = false;
    };

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;
        m_fields->m_pendingPressTime = -1.0;
        return true;
    }

    void handleButton(bool down, int button, bool isPlayer1) {
        auto& state = HackState::get();
        if (state.clickBetweenFrames) {
            // Record the exact timestamp of the input so it can be
            // reapplied at sub-frame precision during the next physics step.
            m_fields->m_pendingPressTime = getSceneDelta();
            m_fields->m_pendingPressDown = down;
        }
        PlayLayer::handleButton(down, button, isPlayer1);
    }

private:
    static double getSceneDelta() {
        return CCDirector::sharedDirector()->getDeltaTime();
    }
};
