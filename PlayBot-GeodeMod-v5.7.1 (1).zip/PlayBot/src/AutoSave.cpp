#include "AutoSave.hpp"
#include <Geode/modify/PlayLayer.hpp>

using namespace geode::prelude;
using namespace playbot;

void AutoSaveManager::reset() {
    m_timer = 0.f;
}

void AutoSaveManager::tick(float dt, PlayLayer* pl) {
    if (!pl || !pl->m_isPracticeMode) {
        reset();
        return;
    }
    if (!Mod::get()->getSettingValue<bool>("auto-save")) return;

    m_timer += dt;
    float interval = static_cast<float>(Mod::get()->getSettingValue<int64_t>("auto-save-interval"));

    if (m_timer >= interval) {
        m_timer = 0.f;

        // storeCheckpoint() is the same call the in-game practice
        // "checkpoint" button triggers - we're just automating it on a timer.
        pl->storeCheckpoint();

        Notification::create(
            "PlayBot: checkpoint auto-saved",
            NotificationIcon::Success,
            1.0f
        )->show();
    }
}

class $modify(PBAutoSavePlayLayer, PlayLayer) {
    void update(float dt) {
        PlayLayer::update(dt);
        AutoSaveManager::get().tick(dt, this);
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        // Keep the auto-save timer running smoothly across resets rather
        // than re-triggering immediately on every death.
    }

    void onQuit() {
        AutoSaveManager::get().reset();
        PlayLayer::onQuit();
    }
};
