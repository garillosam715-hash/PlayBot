#pragma once
#include <Geode/Geode.hpp>

using namespace geode::prelude;

namespace playbot {

// Central, easy-to-query state for every toggle in the mod.
// Kept as plain static state (backed by Geode's mod settings) so any
// hooked class can cheaply check "is X enabled right now".
class HackState {
public:
    static HackState& get() {
        static HackState instance;
        return instance;
    }

    bool noClipEnabled      = false;
    bool speedhackEnabled   = false;
    bool clickBetweenFrames = false;

    float speedMultiplier   = 1.f;

    // Pulls current values from mod settings (call on load + on settings change)
    void refreshFromSettings();

private:
    HackState() { refreshFromSettings(); }
};

} // namespace playbot
